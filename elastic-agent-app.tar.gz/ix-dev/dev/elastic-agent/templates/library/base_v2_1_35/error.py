class RenderError(Exception):
    """Base class for exceptions in this module."""

    pass
